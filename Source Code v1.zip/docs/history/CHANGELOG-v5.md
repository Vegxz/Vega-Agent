# Vega v5 — what changed and why

Verified by the project's own stack, now at **89 source contracts + 665
behavioural assertions**, all passing, plus a full compile against generated
Android stubs and a real release build.

**This APK is signed with a NEW key, so it will NOT install over v3/v4** — uninstall
the old app first. See `keystore/README-KEYSTORE.md`; the old app's chat history and
saved API key go with it.

---

## First, the honest part: half of this list was already done

The screenshots came from a build made before v4 landed, so ten of the twenty-odd
items were already correct in the source I was handed. I verified each of them
rather than rewriting them:

| Already correct | Where |
|---|---|
| The user's bubble sits on the **right** in Persian | `Gravity.END` + a chassis pinned LTR |
| Drawer and settings open from the **left** in Persian | same |
| Tapping the review strip opens a **panel** | `showThoughtsSheet` |
| A search row opens **Web Results**, each opening its source in the browser | `showWebResultsSheet` |
| **No strip at all** on a turn that used no tools | `Trail.didWork()` |
| The "N pages" pill lives **inside** the panel | `sourcesPill`, one call site |
| The header reads the product name, **centred** | one write, `refreshTitle` |
| The permission card is **inset** from both screen edges | 16dp either side |
| The composer's focus ring **clears** when you touch the conversation | `releaseComposerFocus` |
| Diffs are **red and green** in both themes | `Theme.DIFF_*` |

What follows is the work that was actually missing, plus the polish you asked for
on top.

---

## 1. Reasoning no longer sits outside the review box

The strip owned reasoning in theory and not in practice. One code path — the token
flusher — built the collapsed "Model reasoning" card with **no ownership check at
all**, so for the whole of every run the model's thinking sat in the transcript
*outside* the box that claimed to hold it. That is the loose panel in your
screenshot.

Two changes, not one:

- The engine now streams reasoning into an **open row on the trail** as tokens
  arrive, throttled to 200ms. Before, reasoning only reached the trail at tool
  boundaries, in one lump — so the panel was empty for exactly as long as there was
  most to read, which is why the card had to exist at all.
- The card is built only when there is **no strip to put the text in**. A turn that
  calls no tool still gets one, because suppressing it there would delete reasoning
  you had just watched arrive. And if the strip appears mid-turn, the card that was
  correct a moment ago is removed rather than left as a duplicate.

## 2. The review strip can actually be collapsed mid-answer

The chevron looked like it collapsed a live run and could not. `paint()` computed
`live || expanded`, which pins the rows open for the whole run and reduced the
chevron to switching between the last three rows and all of them — and the glyph
always pointed down while live, so it also lied about which way it would go.

One rule now: the rows show when the strip is expanded. The engine still expands at
the start of a run and folds when the answer begins, so nothing about the default
changes.

The state is also **persisted**. `Trail.collapsed` was saved with the conversation
and set by the engine, and no view ever read it — expansion was view-local state
that reset on every rebuild, so a strip you opened closed itself again on the next
trail event or a rotation.

## 3. The panel is worth opening

It used to be a bare list of labels. Every number below was already being recorded
and none of it was ever displayed — per-step timings from the first version,
`workCount()` written with the comment "for the panel's subtitle" and never called
once.

- **How long the run took**, how many steps, how many thoughts, how many files.
- **Per-step duration**, so a step that took a minute no longer looks like one that
  took 40ms.
- **Real outcomes.** The panel ignored `status` entirely, so a failed step rendered
  identically to a successful one. Failed is marked in the palette's real red;
  stopped is marked as stopped.
- **`+N −N` per row** and for the run as a whole.
- **Reasoning as a quoted block** with a hairline rail, not bare prose — in a list
  that now carries timings and counts, unstyled text read as a row that failed to
  render.
- **Rows are separated** by a hairline inset past the glyph rail, so the run reads
  as a sequence of steps.
- **Copy the whole run** as text. A trail is the most useful thing in this app to
  paste into a bug report and there was no way to get it out.

Collapsed, the strip now carries a one-line digest — `4 steps · 2 files · +31 −6 ·
32 pages` — because "Thought for 14s" alone says nothing about what happened.

## 4. Editing shows its work, and the diff is in the panel

`edit_file` reported progress from exactly one place: the middle of a multi-edit
loop. Everything else was silent, including the parts that actually take the time.

Now reporting: the **read** (which on a large file is the slow part, and used to
happen before anything had been reported at all), the **write**, the single-edit and
line-range forms, `write_file` end to end, recursive **search** and **glob** (with
the folder being walked and a running match count, rate-limited), **downloads**,
**PDF** page extraction, and archive listing and extraction. Eight silent paths, all
of them long enough to look like a hang.

A finished row also stops reading as a stale counter — it said `src/Foo.kt · 7/7`
for ever, in the saved history.

And the change itself is now **kept**: `Diff.hunk` narrows the before/after to the
region that changed plus three lines of context, so tapping an edit row opens the
real diff — removed lines red, added lines green — and it **survives reopening the
conversation**. The old tool card that could show a diff was unreachable dead code
(every tool message is folded into the strip, so the branch that drew it never ran),
and no diff was ever persisted, so even reaching it would have shown nothing.

The line diff moved out of `MarkdownRenderer` into a new `Diff.kt` so the engine can
ask what an edit did from a worker thread with no `Context` anywhere near it. One
implementation, two callers.

## 5. Dynamic Workflow: eleven defects

| | Defect |
|---|---|
| Blocking | Every publish after a **re-homed trail** drew nothing. The engine nulls `Message.trail` when it drops a step, and the UI opened with `owner.trail ?: return` — so "Retrying" and, worse, `settleAll` silently never arrived. A run that re-homed on its last iteration left a strip spinning for ever. The board was skipped too, because it was bound below that early return. |
| Blocking | A **stale claimed phase** on the fault path. That branch `continue`s without clearing `activePhase`, so the next unrelated tool resolved it — a `read_file` would mark the delegated phase DONE and write its own first line into the phase's note. |
| Blocking | The sub-agent's **"N steps" never reached the screen.** It was written to the phase and nothing published; the count appeared all at once at the end. The comment claiming it was live was wrong. |
| Blocking | An **unnamed `task`** created a phase with an empty title: a blank row live, and no row at all after a reload, taking the whole board with it when it was the only phase. It now falls back to the brief's own first line. |
| High | A **killed run reloaded as a total success.** Both models rewrote `RUNNING → DONE` on settle and on load. There is a `STOPPED` state now, and stopping a run records it — which matters most for an edit, where the file on disk may be half written. |
| Medium | `Workflow.running` was **write-only dead state**, so the board could not tell a live run from history. It says which now. |
| Medium | **Phase matching was language-fragile.** It only lowercased, so `"۱. بررسی فایل‌ها:"` never matched a bare task name — numbering, colons and the zero-width non-joiner all counted as part of the words, Persian plans scored zero against every name, and the board silently filled rows in call order. Punctuation is stripped and the word-length floor drops for non-Latin script. |
| Medium | The **spinner reset on every publish.** `bind` rebuilt it several times per step, so the arc visibly jumped back to zero — which reads as the work restarting. It is now the one child that survives a rebuild. |
| Medium | **Two boards, one tracker.** A rebuild used the live entry point, so a transcript with two workflow runs overwrote the tracker and the earlier board froze; a re-bind whose view had been detached added a second board. Keyed on the board now, exactly as the strip is keyed on its trail. |
| Medium | **Turning the mode off mid-run** left a phase RUNNING with no resolver. |
| Low | The board never showed what was **queued**, so the decomposition — the entire point of the mode — was invisible until the last phase was claimed. |

## 6. The icons are genuinely lighter

Three separate things were making them heavy, and the constant was only one of them.

- **Five sites hard-coded `1.9f`** — 42% heavier than the shared width — including
  *every sheet header glyph in the app*, which was the single heaviest mark on
  screen. A source contract now fails if any call site hard-codes a stroke again.
- **The optical ramp was a no-op below 20dp.** A 14dp glyph carried a 20dp glyph's
  stroke: 43% more ink around 30% less shape. That is what "too thick" was pointing
  at — not the number, but the number applied unchanged to the 14–18dp sizes this
  interface is almost entirely built from. The ramp now lightens in both directions.
- **Whole-pixel snapping quantised the ramp out of existence.** At 3x density every
  size from 14dp to 24dp rounded to the same 4px, so `1.45` was never rendered at
  all and the correction could not have any effect. Snapping is on the half-pixel
  grid now, which keeps the crispness (the origin is still snapped whole) and leaves
  enough resolution for the sizes in use to differ.

The constant is **1.34** as a consequence, not a guess: it is the width that renders
as 4px at 3x — what the app already looked like at its most common density — so
nothing gets heavier anywhere, while 2x drops from 1.50dp to 1.25dp and the small
glyphs at 3x drop from 1.33dp to 1.17dp.

Two more:

- **The overflow dots** were `M12 5h.01` — a dot only because the round cap draws
  one, which makes its diameter *exactly* the stroke width. Three hard 4px blobs
  that got heavier every time the stroke did. They are real circles now, filled, so
  their size is geometry.
- **Row glyphs dropped one ink level**, `TEXT` → `TEXT_MUTED`. A row's glyph is not
  its subject; the label is. Twenty full-ink glyphs down a settings screen were
  twenty marks competing with the words beside them at the same weight, which is
  most of why the set read as *dark* rather than merely thick.

## 7. The conversation menu is a small anchored menu

⋮ opened a full-width bottom sheet: a modal surface that dims the app and slides up
from the far edge of the screen, for a three-line overflow on one row of a list. It
also cost two sheets to delete anything, since the confirmation is a sheet too.

It is now a 196dp card anchored to the ⋮ that opened it, flipping above the button
when there is no room below, dismissed by a tap anywhere. Built as an overlay in the
root frame rather than a `PopupWindow` — a popup needs a live window token and is a
known source of `BadTokenException` and leaked windows — which is the same rule the
tap-to-copy panel follows, and both are now held to it by contract.

## 8. Settings reads as a list of groups again

- **Headings are a different size**, not just a different weight. Heading and
  footnote were both 13sp, one step of weight apart, at the same indent — nine of
  those down a column is one undifferentiated list.
- **All nine groups have the same silhouette.** Three of them were a heading over a
  bare track with no card while six were a heading over a filled card, so a third of
  the screen looked like a different design.
- **The input rows are no longer the tightest thing on screen**, and the three key
  fields agree: they were at 8dp, 10dp and 11dp of vertical padding, so adjacent
  inputs were different heights for no reason anyone chose.
- **Contrast raised where it was under the floor.** Row chevrons were at 3.24:1 on
  the light palette — below the 4.5 readable minimum, on the mark that tells you a
  row opens something. Unselected segment labels were at the documented 4.82 floor
  for a control whose whole job is to show four choices; selection is already
  unambiguous from the solid pill.
- **The About row lines up.** Its 40dp brand mark sat in a slot sized for a 20dp
  glyph, so the row's leading edge was 20dp further out than the two rows beneath it.
- Segment cells got an honest 44dp touch target, and about fifteen off-scale spacing
  literals went back onto the six-step scale.

## 9. The permission card is a card

Insetting it fixed *where* it sat. This fixes *what it is*: a filled panel with a
hairline, a titled glyph chip and its explanation set as prose — instead of a 2dp
rail with semibold full-ink body copy, which is the treatment a quiet inline note
gets, for the most consequential permission the app asks for.

## 10. Smaller things

- **One product name.** `HEADER_BRAND` said "Vepro Agent" and `APP_NAME` said "Vega
  Agent", in the same build — the header disagreed with the drawer heading and the
  About row. There is one string now, "Vepro Agent", and the header shows it centred.
  The launcher label stays "Vega".
- **The composer's focus ring is 60% accent, not solid.** `ACCENT` is pure near-black
  on the light palette and near-white on the dark one, so a solid 2dp ring drew a
  hard black — or hard white — outline around the one control that is always on
  screen. Same colour, same width, 40% less shout.
- **The message bubble** and the composer are on the spacing scale; both had four
  off-scale numbers and a one-dp asymmetry.
- `Trail.phase` is `@Volatile`. It was the one cross-thread field in the trail model
  that was not, with five engine writers and two main-thread readers.
- Dead code and false comments from the v4 migration removed: `MIN_PILL_SOURCES`,
  the drifted private icon mapping in `MainActivity` (its copy had no reasoning case,
  so a reasoning row in the panel fell through to the generic tool glyph),
  `MAX_OPTICAL` (now actually enforced), the comment claiming a live strip could be
  quieted, and the `addUserRow` comment still describing the mirrored chassis that
  caused the original bug.

---

## Verification performed

| Suite | Result |
|---|---|
| `runtests.sh --source` (contracts + `check_ui` + `check_layoutparams`) | 89 checks, pass |
| `runtests.sh --offline` (full compile against generated stubs, no SDK) | 0 errors, 144 classes |
| `runtests.sh --jvm` (behaviour over loopback HTTP servers) | 665 assertions, pass |
| `mkapk.sh` release build | signed, aligned, verifies v1+v2+v3 |

Baselines were run on the untouched v4 tree first (89 / 0 / 612) so every number
above is a comparison rather than a claim.

**Not** verified: on-device runtime behaviour. No emulator was available, so the
visual work was checked by compile, static cross-reference, the behavioural suite
and review — not by looking at it on a screen.

### New contracts added

Fifty-three new behavioural assertions and new source contracts covering: the
half-pixel snap and the bidirectional ramp, no hard-coded stroke widths anywhere,
the anchored menu (and that it is neither a sheet nor a popup, and is dismissed from
the drawer and on destroy), the diff narrowing and its caps, a file change surviving
a round trip, an unnamed phase keeping a title, a stopped run recording itself as
stopped, Persian plan lines matching Latin task names, and the strip's digest.
