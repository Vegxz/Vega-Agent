# Vega v3 — what changed and why

Ten reported problems, each fixed at its root cause rather than at the symptom.
Every change is covered by the project's own test stack (`./runtests.sh`), which
now runs **74 source contracts + 584 behavioural assertions** and passes clean.

---

## 1. The watermark logo now fits the space that actually exists

**Was:** fixed at 52% of screen width, pinned to 40% of screen height, and moved
only when the IME inset *changed*.

**Root cause:** three separate ones. The update was gated on
`if (ime != imeInsetPx)`, and `imeInsetPx` outlives `buildUi()` — so after any
rebuild while the keyboard was open (theme flip, language change) the fresh mark
started at rest, the next inset pass reported the *same* height, the gate rejected
it, and the mark stayed full-size behind the keyboard. On API 24–29 the IME height
has to be inferred by subtracting two other insets, which yields 0 on any OEM
whose stable inset tracks the keyboard. And the size was never compared against
the header/composer band at all, so it could overlap content.

**Now:** the mark is centred in, and scaled to, the **measured** transcript
viewport (`watermarkBand()` — real `getLocationInWindow` geometry, minus the
suggestion rows). The keyboard is no longer a special case: it is simply a smaller
band, so the same arithmetic also handles split-screen, a three-line composer and
a tall OEM keyboard. An `addOnLayoutChangeListener` re-places it on every layout
change, and the update is idempotent so the keyboard's own animation frames don't
restart the tween.

## 2. A run never stops in the middle of a task

**Root cause:** four silent exits in `AgentEngine.run()`.

- A turn with prose but no parsable tool call called `onComplete()` — the run was
  declared *finished*. This is the reported "stops in the middle of a web search":
  the model printed a `json` block, one character was invalid, the parser returned
  null, and the task was abandoned next to the raw JSON card.
- A stream error terminated the whole run (the client retried the *request*;
  nothing retried the *step*).
- One thrown exception from any step killed the run.

**Now:** a malformed call is treated as a typo, not a decision — the model is told
exactly what was wrong and asked to re-emit (up to 6 times). Stream failures retry
the step behind a widening backoff (up to 6 times). A thrown step is handed back
as a tool error and the run continues. Prose that merely *announces* the next step
("now I'll search for…") is probed before being accepted as final. Every bound is
explicit, so a stuck model still cannot loop.

## 3. Tool-call JSON is never visible

**Root cause:** `stripToolCalls` hid only a **complete, valid** call, and the fence
regex requires a closing ```` ``` ````. So for the entire time a call was arriving
there was nothing to strip and the renderer drew a live "json" code card; a call
with a syntax error never became strippable at all and stayed on screen for good.

**Now:** anything *shaped* like a tool call is hidden — complete or not, valid or
not — including an unfenced object the model is halfway through typing, and a
`json` fence whose info line hasn't even finished. A genuine JSON *document* in an
answer is still shown (the `onlyCallKeys` rule that stops `parseToolCall`
executing a `package.json` now also stops the stripper deleting one), and streamed
code keeps its braces.

## 4. Planning

- **Blank steps.** A markdown rule (`---`) matched the old bullet test, and
  stripping one `-` left the literal text `--` — those were the "--" rows. A bare
  `1.` reduced to an empty string the same way. There is now one shared parser
  (`AgentEngine.isPlanStep` / `planLines`) that rejects rules, table separators and
  bare numbers, and the sheet uses it instead of its own regexes.
- **Approving a permission cancelled the plan.** Escalating PLAN → ACCEPT for a
  mutating call was **persisted** to prefs. The plan sheet's guard reads
  `prefs.mode()`, so the sheet never appeared for the very run that was carrying
  the plan out — and the user's chosen mode was rewritten behind their back for
  every future turn. The escalation is now run-local.

## 5. Smoother text reveal

**Root cause:** a `Handler.postDelayed(16ms)` loop. 16 ms is *approximately* a
frame at 60 Hz and nothing at all at 90/120 Hz, so the callback and the display
drift in and out of phase and a mathematically smooth ramp is *sampled* unevenly.
No duration tweak can fix that.

**Now:** `Choreographer` — one callback per real frame at the panel's own rate.
The ramp starts at zero opacity on a quintic ease-out over 340 ms with a 26 ms
per-word cascade, and the cascade's total length is capped so a large flush can't
leave the tail lagging.

## 6. Icons and controls

Icons were technically fine and looked cheap: a 24-unit drawing scaled into an
arbitrary box lands on fractional pixels, and a 1.5 dp stroke straddling two pixel
columns is drawn as two half-lit columns. The origin and the stroke width are now
**snapped to whole pixels**, the single stroke width went 1.5 → 1.7 dp, and a
bounded optical ramp (±12%) evens small glyphs against large ones. Filled controls
gained a hairline rim of their own ink so they read as drawn rather than as flat
silhouettes, and the composer floats at 3 dp instead of 2.

## 7. The live activity strip (new)

A run's only narration was a transient one-line pill, so the most prominent thing
on screen while the agent worked was its own raw JSON.

There is now a **transparent strip** above the answer: an animated dot-matrix
glyph, the current phase in the model's own words, a live elapsed-seconds counter,
and a streaming list of rows — *Searching* with the query in italic, *Opened page*
with the domain, each with a cluster of source circles and a result count. When the
answer starts it folds to a single **"thought for N seconds"** line plus an
"N pages" pill. Tapping expands the whole run.

Intermediate steps now *fold into* the strip (`Message.isStep`) instead of being
separate bubbles — which is what removes the JSON card from the conversation
entirely. It is persisted with the chat, so reopening a conversation shows the same
history rather than an empty strip.

The source circles are monochrome monograms rather than real favicons: this
interface is strictly greyscale, and dropping full-colour icons into it is the one
thing guaranteed to make it look cheap. It also needs no network request, no
cache, no decoder and no fallback for the many hosts whose icon is a 404.

## 8. Dynamic Workflow is visible (new)

The `task` tool really did spawn real sub-agents with their own clean context and
step budget — and showed the user nothing at all. There is now a **board**: the
decomposition (taken from the plan the lead agent wrote, in the user's own
language), which phase is running, how many steps each sub-agent took, and the
one-line result each handed back.

## 9. Correctness

`Trail`, `TrailStep`, `Workflow` and `WorkPhase` are mutated by the engine's worker
thread and read by the UI thread microseconds apart. Their collections are private
and every path in or out is synchronized; readers get snapshots; cross-thread
scalars are `@Volatile`. A stress test drives 4 000 mutations against a live reader
to prove it. Also fixed in review: duplicate strips when a trail was re-homed, a
board spinner that could outlive a cancelled run, a publish that silently did
nothing once the owner was cleared, prose being discarded to retry one bad fence,
and `Util.truncate`'s machine suffix leaking into one-line labels.

## 10. Build

`Vega-v3.apk`, version 3.0 (300), signed v1+v2+v3 with a **new 4096-bit key** —
see `keystore/README-KEYSTORE.md`, and note that the old app must be uninstalled
first.

---

## Verification performed

| Suite | Result |
|---|---|
| `runtests.sh --source` (contracts + `check_ui` + `check_layoutparams`) | 74 checks, pass |
| `runtests.sh --offline` (full compile against generated stubs, no SDK) | 0 errors |
| `runtests.sh --jvm` (behaviour over loopback HTTP servers) | 584 assertions, pass |
| `mkapk.sh` release build | signed, aligned, verifies v1+v2+v3 |

**Not** verified: on-device runtime behaviour. No emulator was available, so the
visual work was checked by compile, static cross-reference, behavioural tests and
review — not by launching the app on a screen.

### Repo-level fixes made along the way

- `tools/gen_stubs.py` — the offline stub set gained `Choreographer`, `Canvas`
  circle/text/arc, `Paint` text metrics, `Typeface.ITALIC` and the `View` hooks a
  custom view overrides, so the no-SDK compile still covers the whole app.
- `runtests.sh` — the `--jvm` suite never actually ran: it used `mapfile < <(…)`
  (needs `/dev/fd`), never generated `R.java`, and pulled `org.json` from
  `android.jar`, whose every method throws `Stub!`. All three fixed; it now runs.
