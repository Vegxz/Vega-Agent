# Vega v6 — the no-answer bug, and why nothing caught it

Displayed version **1**. Signed with the **same key as v5**, so it installs straight
over what you have — no uninstall, and your API key and settings survive.

---

## What was actually wrong

Two things, and the second one is the real defect.

### 1. The new signing key wiped every setting

v5 needed an uninstall, so Settings went back to defaults: base URL
`https://api.openai.com/v1`, model `gpt-4o`, protocol `auto`. Pasting a key from a
different platform still sent the request to OpenAI, which rejected it. That is why
three keys from three platforms all failed — they were all going to the same wrong
endpoint. Nothing was wrong with the keys.

### 2. The app failed in complete silence

This is the part that matters, because it would have hidden any other cause just as
well.

When a request failed, the engine retried **six times** with 0.9s / 2.2s / 4.5s / 8s /
8s / 8s of backoff — about 32 seconds before it even considered reporting anything,
plus up to six request timeouts on top. Through all of it:

- the "Retrying" phase was written to the review strip, but the strip is **hidden** on
  a turn that used no tools, and a request that never connects uses none;
- the running indicator only appears once a **tool** starts, so it never appeared;
- the provider's own rejection message was held back until the retry budget ran out.

Which is exactly your screenshots: stop button lit, bar sweeping, transcript blank.

### 3. Why every suite passed anyway

`AgentEngine.run` — the agent loop, the thing the app is for — **had no test at all**.
665 assertions covering the parsers, the trail model and the HTTP client, and not one
of them ever called it. So "all suites pass" was never evidence that sending a message
works, and the first person to find out was you.

---

## The fixes

### Nothing fails in silence any more

| Before | Now |
|---|---|
| Six retries before any word, ~32s of backoff | **Two** retries while nothing has been shown; the full six only once there is work worth protecting |
| Reason withheld until the budget ran out | The provider's own message is on the strip from the **first** attempt |
| "Retrying" with no count | "Retrying (2 of 2)", and the failure is a real row that survives into the Thoughts panel |
| Strip hidden for the whole of a failing request | A live run **always** has something to say — the strip appears the moment you send |
| Opening phase claimed "Thinking about your request" while waiting on a socket | Says **Connecting**, then switches to thinking when the first token actually arrives |

### A configuration that cannot work never costs a request

`Preflight` runs before a single byte leaves the phone and names the certain cases:
no key, no model, an unusable endpoint, and a **key aimed at the wrong service** —
your case. An Anthropic key pointed at `api.openai.com` now produces, instantly:

> Your key belongs to Anthropic but the request goes to api.openai.com, which will not
> accept it.
> In Settings, point the server address at Anthropic: `https://api.anthropic.com/v1`

It fires only on cases that are *certain* to fail. A known key against an unknown
host is the normal shape of a self-hosted gateway or proxy and passes straight
through — blocking that would be worse than the bug. Unfamiliar key formats pass too.

### A key you cannot save

Found while fixing the above. `SecureStore.encrypt` returned null when the device's
keystore was unavailable, and `Prefs.setApiKey` turned that into `false` — so on those
devices **the API key could never be saved at all**, every request went out
unauthenticated, and nothing on screen explained it. The key is now stored with an
explicit marker instead of being thrown away, and Settings says plainly that it is not
hardware-protected.

### Settings answers the connection question first

The screen used to open on a heading called "Provider" above three text fields, with
the Test button further down past the protocol segment. Now the first thing on it is a
connection card: the endpoint, model and protocol that will **actually** be used, any
problem Preflight can see without touching the network, and the test action itself.
It follows the fields as you type rather than describing what the screen opened with.

### The loop is finally tested

`AgentLoopTests` drives the real `AgentEngine`, with the real `LlmClient`, over real
loopback sockets — 62 assertions on what a user would actually see:

- a plain question gets an answer;
- reasoning becomes trail rows the panel can show;
- a tool call runs, feeds back, and the answer follows;
- **a rejected key is reported at once**, in bounded attempts, in under 20 seconds;
- **a mismatched key never leaves the phone** (asserted: zero requests made);
- a live run is never drawn as a blank transcript;
- the whole Preflight table, including every case that must *not* be blocked;
- a secret survives a device with no working keystore.

It runs against the generated Android stubs, not a real `android.jar` — android.jar is
signature-only, so every method in it throws `RuntimeException("Stub!")` the moment it
is called and a `Context` cannot even be constructed there. `gen_stubs.py` gained a
behavioural `Context`, `ContextWrapper` and `SharedPreferences` so the loop has
somewhere real to run, and `runtests.sh` now executes both behavioural suites as part
of the standard run. It does not get to be optional.

---

## The rest of your list

- **Vega Agent** everywhere — header, drawer, About row, service notification. One
  string, so they cannot disagree again.
- **Version 1** as displayed. The internal version code still rises (13), because
  Android refuses an update otherwise; only the name is ever shown.
- **Sharper logo.** Same shape, no redraw. The generator went from 4×4 to 16×16
  samples per pixel and from 24 to 64 curve segments. Measured on the 432px
  foreground: **17 distinct alpha levels along the star's edge before, 256 now** — the
  raggedness was the sampling, and it is now limited by the pixel grid and nothing
  else. All 25 rasters regenerated.
- **Shorter suggestions**, in both languages:
  - "محتوای پوشه‌ی دانلود من را فهرست کن" → **"پوشه دانلود را نشان بده"**
  - "وب را جست‌وجو کن و نتایج را خلاصه کن" → **"در وب جست‌وجو کن"**
  - "List the contents of my Downloads folder" → **"Show my Downloads folder"**
  - "Search the web and summarize the results" → **"Search the web"**
- **The suggestion glyph sits on the right in Persian.** This is the one place the
  chassis is mirrored, deliberately: a suggestion is not furniture, it is a sentence
  you are about to say, and its glyph reads as the first character of it. Setting the
  direction on that row alone moves the glyph, the gap and the padding together and
  leaves every other layout untouched — the single-chassis rule that fixed the drawer
  and the outgoing bubble still holds everywhere else, and a contract enforces it.
- **The error card is a card now**, in the same language as the storage-permission
  notice: a filled panel with a hairline, a titled glyph chip, the first line as a
  headline and the provider's detail as selectable prose beneath it — instead of a 2dp
  rail with everything in semibold full-ink 13sp, which shouted while staying hard to
  read. It carries a button straight to Settings, because every failure it reports is a
  credential, an endpoint or a model.

---

## Verification

| Suite | Result |
|---|---|
| `runtests.sh --source` | **95** contracts, pass (was 89) |
| `runtests.sh --offline` | 0 errors, 146 classes |
| `CoreRegressionTests` | 665 assertions, pass |
| **`AgentLoopTests`** | **62 assertions, pass** — new, and the loop's first test ever |
| `mkapk.sh` | signed, aligned, verifies v1+v2+v3 |

Six new source contracts, covering: the preflight call site and its ordering trap,
the reduced silent-retry budget, the failure reaching the trail, the loop suite being
wired into the standard run, a secret never being discarded, the connection card being
first on the settings screen, the mirrored suggestion row being the *only* mirrored
thing, and the logo's sampling.

**Still not verified:** on-device behaviour. There is no emulator here. What changed
this round is that the run loop is no longer in that category — it executes against
real sockets in the suite above. The visual work is still checked by compile, static
cross-reference and review.

---

## If it still does not answer

Open Settings. The card at the top now tells you what is wrong, and **Test connection**
gives you the provider's own answer in about a second instead of a blank screen. If it
reports a mismatch, the line under it names the endpoint your key belongs to.
