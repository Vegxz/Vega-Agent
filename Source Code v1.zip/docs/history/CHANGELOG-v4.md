# Vega v4 — what changed and why

Fifteen requests on top of v3. Verified by the project's own stack, now at
**89 source contracts + 612 behavioural assertions**, all passing, plus an
independent audit of the diff whose six findings are all fixed and covered by
tests.

**This APK installs straight over v3** — same signing key, no uninstall needed.

---

## 1. Persian no longer mirrors the interface

The drawer, settings, composer controls and menus now sit on the **left** in both
languages, exactly as in English. Persian **text** still reads right-to-left
inside its own block, which is how ChatGPT and Grok do it: one chassis, text in
its own direction.

Mirroring caused two of the reported bugs by itself. The user's own message bubble
is `Gravity.END`, and under a mirrored layout END *is* the left — so the outgoing
turn sat on the wrong side of the conversation. The drawer, being `Gravity.START`,
slid in from the right. Both are fixed by the flip, not by special cases.

`Lang.direction()` is the single source now, and the handful of places that must
know which *physical* edge they are anchored to ask `Lang.mirrored()` instead of
testing the language as a proxy. Four affordances were still asking the old
question and all four pointed the wrong way in Persian — the settings back
button, two row chevrons and the rail inset.

## 2. The review strip is a panel now

Tapping it opens a **Thoughts** sheet: the phase, every action in order, and the
sources pill that used to sit loose in the transcript underneath. Tapping a search
row opens **Web Results** — the actual results that search returned, each card
opening its source in your browser.

The results were always there; the search tool built titles and urls and then
flattened them into the string it hands the model, so nothing kept the structure
and a row could say "10 results" while offering no way to see one. `Web.SearchResult`
keeps them, and a per-call `Tools.Observer` carries them to the row that produced
them.

The strip no longer expands in place — a growing list in the middle of the
transcript pushed the answer around while it was being read. The chevron still
folds the live rows away, so a run can be made quiet without losing the way in.

## 3. Reasoning moved into the panel

The model's thinking is now a row in the Thoughts panel, in the order it happened,
between the step it followed and the step it led to — instead of a separate
collapsed card telling half the story out of sequence.

Two ways this could have lost text, both fixed:

- A turn that calls **no tool** has a hidden strip and therefore no reachable
  panel; and a conversation saved by **v3** has a trail with no reasoning rows in
  it. In both, hiding the card would have deleted reasoning you had just watched
  arrive. The card is now only suppressed when the panel is provably reachable
  *and* populated.
- On a truncation **resume**, the reasoning buffer is folded away and cleared. It
  is flushed to the panel first now, so a long answer's earlier rounds survive.

## 4. No strip when nothing happened

A turn that used no tools has no work to narrate, so it gets no strip at all.
"Reviewed for 2 seconds" over a one-line reply is noise dressed as progress —
every turn thinks, so thinking alone is not the test (`Trail.didWork()`).

## 5. Lighter icons and logo

v3 raised the stroke to 1.7dp **and** added up to 12% on small glyphs. Stacked,
the 14–18dp sizes the interface is mostly made of came out looking inked. The
stroke is back to **1.45dp**, the optical ramp can now only ever *lighten*, and
the watermark is quieter. The pixel snapping stays — that is what actually made
them crisp, and it is why 1.45dp no longer looks thin.

## 6. A menu on each conversation

⋮ opens **Delete / Rename / Pin**. It used to fire the delete sheet directly,
which made ⋮ a disguised trash can one tap from the row you press to open a chat.
Pinning is real: stored with the conversation, and pinned chats sort above
everything else. Delete is tinted with the palette's one real red — `Theme.RED` is
a near-black grey here, so the old "destructive" marking rendered identically to
the other rows.

## 7. Diffs carry colour

Removed lines are red, added lines green — GitHub's own restrained values, in both
themes. This is the **one** exception to the monochrome palette, and it is
deliberate: added and removed are opposites, not two amounts of one thing, and
lightness alone cannot say which is which. Previously both were washes of the same
grey and the `+`/`−` glyph did all the work.

## 8. Editing shows its work

`edit_file` reported nothing until it finished, which on a large file or a long
list of edits is indistinguishable from the app hanging. It now reports the file
it opened and its progress through a multi-edit (`3/7`), live, on its activity row.

## 9. Smaller fixes

- **Header** shows the product name, centred, instead of the conversation title —
  which moved on every turn as the auto-title was rewritten. Four separate code
  paths were still painting the chat title over it; there is now exactly one write.
- **Composer focus ring** clears when you touch the conversation. The ring is
  drawn from the field's focus state and nothing ever took that focus away, so it
  stayed lit around a box you had visibly stopped using.
- **Storage permission card** is inset from both edges instead of running flush
  into the sides of the screen.
- **Settings** headings are real headings now (semibold, full-contrast, more air
  above than below so a heading belongs to what follows it), and the explanatory
  paragraphs moved from the palette's faintest ink to muted, with more leading.
- **Dynamic Workflow** board is attached to a message that always exists — it was
  hung off a reference cleared whenever a step was dropped, so the board could end
  up attached to nothing, never rendered and never saved.

## 10. Defects found by the audit and fixed

| Severity | Defect |
|---|---|
| Blocking | Reasoning vanished on no-tool turns and in every pre-upgrade chat |
| Blocking | Four code paths still painted the chat title over the header brand |
| Medium | Four affordances pointed the wrong way in Persian after the flip |
| Medium | A truncation resume dropped its earlier reasoning from the panel |
| Low | An abandoned tool worker could inject a finished run's strip into another chat |
| Cosmetic | The delete row's "destructive" tint rendered as ordinary text |

---

## Verification performed

| Suite | Result |
|---|---|
| `runtests.sh --source` (contracts + `check_ui` + `check_layoutparams`) | 89 checks, pass |
| `runtests.sh --offline` (full compile against generated stubs, no SDK) | 0 errors |
| `runtests.sh --jvm` (behaviour over loopback HTTP servers) | 612 assertions, pass |
| `mkapk.sh` release build | signed, aligned, verifies v1+v2+v3 |

**Not** verified: on-device runtime behaviour. No emulator was available, so the
visual work — and the layout flip in particular, which is visual by nature — was
checked by compile, static cross-reference, behavioural tests and review, not by
looking at it on a screen.

### Repo-level fixes made along the way

- `tools/gen_stubs.py` — the no-SDK stub set gained `TEXT_ALIGNMENT_CENTER`, the
  `View` focus methods and the three-argument `addView`, so the offline compile
  still covers the whole app.
